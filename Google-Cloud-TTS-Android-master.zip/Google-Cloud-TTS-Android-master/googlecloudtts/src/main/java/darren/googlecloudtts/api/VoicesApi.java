package darren.googlecloudtts.api;

import darren.googlecloudtts.response.VoicesResponse;

/**
 * Author: Changemyminds.
 * Date: 2020/12/17.
 * Description:
 * Reference:
 */
public interface VoicesApi {
    VoicesResponse get();
}
