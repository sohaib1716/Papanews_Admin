package darren.googlecloudtts.exception;

/**
 * Author: Changemyminds.
 * Date: 2020/12/17.
 * Description:
 * Reference:
 */
public class OutOfScopeException extends RuntimeException {
    public OutOfScopeException(String message) {
        super(message);
    }
}
