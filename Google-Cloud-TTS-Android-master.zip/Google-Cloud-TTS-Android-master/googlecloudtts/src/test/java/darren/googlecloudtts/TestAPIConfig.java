package darren.googlecloudtts;

/**
 * Author: Changemyminds.
 * Date: 2021/2/20.
 * Description:
 * Reference:
 */
class TestAPIConfig {
    static final GoogleCloudAPIConfig CONFIG = new GoogleCloudAPIConfig(BuildConfig.API_KEY);
}
